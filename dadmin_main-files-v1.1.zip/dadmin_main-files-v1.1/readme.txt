DAdmin is a Responsive Bootstrap HTML Admin Dashboard designed to build any kinds of Admin Dashboard Panel. It's an HTML5 template based on latest stable Bootstrap 4.1.1. Anyone can easily update/edit this template to follow our Well Sorted Documentation.


==========================================================================
Well Sorted Documentation included in "documentation" (folder).
==========================================================================


SOURCE AND CREADITS:
====================

Photos:

    All 'images' used on the demo site is for demonstration purposes only and are not included in the main download file.

Fonts:

    Google Fonts (Open Sans and Montserrat)

Frameworks / Libraries:

    jQuery
    jQuery UI
    Twitter Bootstrap

Plugins:

    DataTables
    Dropzone.js
    FullCalendar
    Ion.RangeSlider
    jQuery Sparkline
    jQuery Steps
    jQuery Validation
    jVectorMap
    Moment.js
    Morris.js
    Perfect Scrollbar
    PrismJS
    Raphael
    Select2
    Summernote
    SweetAlert
    The Final Countdown